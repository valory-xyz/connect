__version__ = "0.5.0"  # the package version (pyproject.toml); the agent reports it to Connect
