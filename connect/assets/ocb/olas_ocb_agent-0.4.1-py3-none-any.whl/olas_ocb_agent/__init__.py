__version__ = "0.4.1"  # the package version (pyproject.toml); the agent reports it to Connect
