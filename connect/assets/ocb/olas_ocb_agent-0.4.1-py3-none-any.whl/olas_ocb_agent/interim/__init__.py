"""Interim code: everything here goes away once a Valory task lands (valory-xyz/onchainbench#3).

Kept apart so a reviewer sees at once what is temporary. Each module names the task that removes it and what
replaces it; README.md maps them all. Nothing outside this package should grow a dependency on it beyond the
imports that exist today.
"""
